create procedure upd(IN pid int, IN pnum int)
  begin
    update t_cart
      set
        num = pnum
    where
      id=pid;
  end;

